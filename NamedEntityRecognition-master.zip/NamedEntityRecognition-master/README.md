# NamedEntityRecognition
NER using LSTMs with Keras, guided project on Coursera
